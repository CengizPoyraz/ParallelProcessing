#!/bin/bash
nvcc -O3 CMPE478-fall-2024-hw2-part-b.cu -o CMPE478-fall-2024-hw2-part-b -lm