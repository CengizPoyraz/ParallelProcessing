#!/bin/bash
./CMPE478-fall-2024-hw2-part-b $1 $2