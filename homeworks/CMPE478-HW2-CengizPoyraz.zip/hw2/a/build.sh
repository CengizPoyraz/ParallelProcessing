#!/bin/bash
mpicc CMPE478-fall-2024-hw2-part-a.c -o CMPE478-fall-2024-hw2-part-a -lm