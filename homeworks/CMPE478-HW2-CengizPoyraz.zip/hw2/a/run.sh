#!/bin/bash
mpirun --allow-run-as-root -np $1 --use-hwthread-cpus --oversubscribe CMPE478-fall-2024-hw2-part-a 4